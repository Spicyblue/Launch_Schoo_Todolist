# Introduction

A simple todolist application built on python 3.8 and supported on all versions from 3.8 and above.
Have fun trying it out.
